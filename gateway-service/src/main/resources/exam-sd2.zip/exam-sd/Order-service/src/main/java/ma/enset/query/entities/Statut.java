package ma.enset.query.entities;

public enum Statut {
    CREE,
    ACTIVE,
    ABANDONNE,
    EN_PREPARATION,
    EXPEDIE,
    LIVREE
}
