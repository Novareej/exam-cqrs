package ma.enset.query.entities;

public enum Etat {
    DISPONIBLE,
    RUPTURE,
    PRODUCTION,
    ABANDON
}
