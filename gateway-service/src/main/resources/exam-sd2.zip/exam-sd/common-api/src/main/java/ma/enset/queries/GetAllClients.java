package ma.enset.queries;public class GetAllClients {
}
