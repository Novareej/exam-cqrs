package ma.enset.queries;

public class GetAllCategories {
}
