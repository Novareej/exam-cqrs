package ma.enset.dtos;

public enum Etat {
    DISPONIBLE,
    RUPTURE,
    PRODUCTION,
    ABANDON
}
