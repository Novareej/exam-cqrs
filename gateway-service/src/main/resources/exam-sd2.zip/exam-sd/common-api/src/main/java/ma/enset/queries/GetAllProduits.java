package ma.enset.queries;

public class GetAllProduits {
}
